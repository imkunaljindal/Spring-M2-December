package com.example.Cricbuzz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CricbuzzApplicationTests {

	@Test
	void contextLoads() {
	}

}
